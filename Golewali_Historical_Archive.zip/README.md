# Golewali Historical Archive
یہ ایک static website ہے۔ مرکزی فائل `index.html` ہے۔
آپ اسے GitHub Pages، کسی web host، یا ChatGPT Sites میں دوبارہ بنانے کے لیے استعمال کر سکتے ہیں۔
